package com.cg.SpringBootRestJpa.service;

import java.util.List;

import com.cg.SpringBootRestJpa.beans.Product;
import com.cg.SpringBootRestJpa.exception.ProductException;

public interface ProductService {

	public List<Product> addProduct(Product pro) throws ProductException;
	
	public List<Product> getAllProducts() throws ProductException;
	//public Product getProductById(long id) throws ProductException;
public Product getProductById(Long id) throws ProductException;

	//public List<Product> deleteProduct(Long id) throws ProductException;
	public void deleteProduct(Long id) throws ProductException;

	public List<Product> updateProduct(Long id, Product pro) throws ProductException;


//public List<Product> updateProduct(long id, Product pro) throws ProductException;

}