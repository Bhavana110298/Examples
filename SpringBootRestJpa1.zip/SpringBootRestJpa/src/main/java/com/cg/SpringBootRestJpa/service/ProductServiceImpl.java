package com.cg.SpringBootRestJpa.service;
/*
 

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.SpringBootRestJpa.beans.Product;
import com.cg.SpringBootRestJpa.dao.ProductDao;
import com.cg.SpringBootRestJpa.exception.ProductException;


@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
    ProductDao productDao;
    
    public List<Product> getAllProducts() throws ProductException {
    	try {
    
    		return productDao.findAll();
    	}catch(Exception e) {
    		throw new ProductException(e.getMessage());
    	}
    }
	 public List<Product> getAllProducts() throws ProductException{
	        try{
	            return productDAO.findAll();
	        }catch(Exception e) {
	            throw new ProductException(e.getMessage());
	        }
	    }

    public List<Product> addProduct(Product pro) {

        productDao.save(pro);
        return productDao.findAll();
    }
    
    public List<Product> addProduct(Product pro) {
    int amount=pro.getPrice()*pro.getQuantity();
    pro.setAmount(amount);
    productDao.save(pro);
    return productDao.findAll();
    }

    public Product getProductById(Long id) {
        return productDao.findById(id).get();
    }


    public void deleteProduct(Long id) {
        productDao.deleteById(id);        
    }
    
    public List<Product> updateProduct(Long id, Product pro) {
    	int amount=pro.getPrice()*pro.getQuantity();
        pro.setAmount(amount);
        Optional<Product> optional=productDao.findById(id);
        if(optional.isPresent())
        {
            Product product=optional.get();
            product.setName(pro.getName());
            product.setModel(pro.getModel());
            product.setPrice(pro.getPrice());
            product.setQuantity(pro.getQuantity());
            
            productDao.save(product);
        }
        
        return getAllProducts(); 

    }

 


}*/






import java.util.List;
import java.util.Optional;

 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.SpringBootRestJpa.beans.Product;
import com.cg.SpringBootRestJpa.dao.ProductDao;
import com.cg.SpringBootRestJpa.exception.ProductException;


 


@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    ProductDao productDao;

 

    @Override
    public List<Product> getAllProducts() throws ProductException{
        try{
            return productDao.findAll();
        }catch(Exception e) {
            throw new ProductException(e.getMessage());
        }
    }

 

    @Override
    public List<Product> addProduct(Product pro) throws ProductException{
        try{
            int amount=pro.getPrice()*pro.getQuantity();
        
        pro.setAmount(amount);
    productDao.save(pro); 
    
    return productDao.findAll();
    }catch(Exception e) {
        throw new ProductException(e.getMessage());
    }
    }

 

    @Override
    public void deleteProduct(Long id) throws ProductException{
    try {
      productDao.deleteById(id);
    //return productDao.findAll();
}catch(Exception e) {
    throw new ProductException(e.getMessage());
    }
    }
    @Override
    public List<Product> updateProduct(Long id, Product pro) throws ProductException{
        try {
        Optional<Product> optional=productDao.findById(id);
        if(optional.isPresent()) {
            Product product=optional.get();
            product.setName(pro.getName());
            product.setModel(pro.getModel());
            product.setPrice(pro.getPrice());
            product.setQuantity(pro.getQuantity());
            int amount=pro.getPrice()*pro.getQuantity();
            product.setAmount(amount);
            productDao.save(product);
            
        }
        return getAllProducts();
    }catch(Exception e) {
        throw new ProductException(e.getMessage());
    }
    }
    @Override
    public Product getProductById(Long id) throws ProductException{
        try {
        return productDao.findById(id).get();
    
}catch(Exception e) {
    throw new ProductException(e.getMessage());
}
}
}

