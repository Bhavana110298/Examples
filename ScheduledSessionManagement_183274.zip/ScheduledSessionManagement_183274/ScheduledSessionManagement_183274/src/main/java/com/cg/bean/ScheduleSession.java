package com.cg.bean;

import java.io.Serializable;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/*Created By:CH.Saranya
Created On:23/07/2019
purpose:Bean Class to get the all fields in the table

*/




@Entity
public class ScheduleSession implements Serializable {
	@Id
	@GeneratedValue
	private Integer sessionId;
	private String sessionName;
	private String facultyName;
	private Integer duration;
	private String modeOfSession;
	
	

	public Integer getSessionId() {
		return sessionId;
	}



	public void setSessionId(Integer sessionId) {
		this.sessionId = sessionId;
	}



	public String getSessionName() {
		return sessionName;
	}



	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}



	public String getFacultyName() {
		return facultyName;
	}



	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}



	public Integer getDuration() {
		return duration;
	}



	public void setDuration(Integer duration) {
		this.duration = duration;
	}



	public String getModeOfSession() {
		return modeOfSession;
	}



	public void setModeOfSession(String modeOfSession) {
		this.modeOfSession = modeOfSession;
	}



	public ScheduleSession() {
		// TODO Auto-generated constructor stub
	}

}
